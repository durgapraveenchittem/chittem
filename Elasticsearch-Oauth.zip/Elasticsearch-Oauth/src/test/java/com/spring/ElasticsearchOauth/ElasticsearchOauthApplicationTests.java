package com.spring.ElasticsearchOauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticsearchOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
